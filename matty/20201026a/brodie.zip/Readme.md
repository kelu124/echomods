# `20201026a` - Testing usb control

## Comparing VGAs

### Without gain control

![](/matty/20201026a/images/no_vga.png)

### VGA

![](/matty/20201026a/images/vga.png)

## More details

### Detail of the echo

![](/matty/20201026a/images/ping.png)

### Interleaving acquisitions at 128 Msps

![](/matty/20201026a/images/128msps.png)
